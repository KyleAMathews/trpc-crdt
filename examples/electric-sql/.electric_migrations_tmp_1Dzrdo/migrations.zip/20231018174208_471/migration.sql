CREATE TABLE "users" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  CONSTRAINT "users_pkey" PRIMARY KEY ("id")
) WITHOUT ROWID;
